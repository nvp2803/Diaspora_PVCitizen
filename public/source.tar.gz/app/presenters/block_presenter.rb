
class BlockPresenter < BasePresenter
  def base_hash
    { id: id }
  end
end

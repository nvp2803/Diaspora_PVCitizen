OpenGraphReader.configure do |config|
  config.synthesize_title = true
  config.synthesize_image_url = true
end

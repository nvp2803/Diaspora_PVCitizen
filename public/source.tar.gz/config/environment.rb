# Load the rails application
require_relative 'application'

# Initialize the rails application
Diaspora::Application.initialize!

# Please read the [translation guide](http://wiki.diasporafoundation.org/Contribute_translations) before contributing!
